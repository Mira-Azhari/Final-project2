const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
    title: String,
    type: String,
    answers: String,
    correctAnswer: String,
    testname: String
});

const Question = mongoose.model("Question", questionSchema);

module.exports = Question;