const mongoose = require("mongoose");
const express = require("express");
const bodyParser = require("body-parser");
const users = require("../routes/users");
const questions = require("../routes/questions");
const tests = require("../routes/tests");
const app = express();
const port = 5001;
app.use(express.json());
app.use(express.urlencoded({extended:true}));
const dbURL = 'mongodb://localhost:27017/Test';

mongoose
  .connect(dbURL,{ useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Connected to MongoDB...");
  })
  .catch((err) => {
    console.error("Connection failed...");
  });

app.listen(port, () => {
  console.log("Server is running at port:" + port);
});

app.use(express.json());

app.use("/api/tests",tests);
app.use("/api/users",users);
app.use("/api/questions",questions);
