const express = require('express');
const router = express.Router();
const Question = require('../models/question');

router.post('/testname', async (req, res) => {
    try{
    console.log("testname:"+req.body.testname);
    let question = await Question.find({testname:req.body.testname});
        if (question){
         return res.send(question);
         }else{
            return res.status(400).send("questions do not exist");
         }
      }catch(error){
            console.log(error);
      }
});

router.post('/', async (req, res) => {

    let question = new Question({
        title: req.body.title,
        type: req.body.type,
        answers: req.body.answers,
        correctAnswer: req.body.correctAnswer,
        testname: req.body.testname
    });

    question.save().then((question) => {
        console.log(question);
        res.status(200).send(question);
    })
    .catch((err) => {
      res.status(500).send(err.message);
    });
});

module.exports = router;