const express = require('express');
const router = express.Router();
const Test = require('../models/test');

router.get('/', async (req, res) => {
     
    try{
        console.log("entered tests post1e");
        let test = await Test.find();
         console.log("entered tests post2e");

         if (test){
         return res.send(test);
         }else{
            return res.status(400).send("User do not exists");
         }
    }catch(error){
        console.log(error);
    }

    
});


router.post('/', async (req, res) => {

    let test = new Test({
        title: req.body.title,
        type: req.body.type
    });

    test.save().then((test) => {
        res.status(200).send(test);
    })
    .catch((err) => {
      res.status(500).send(err.message);
    });
});

module.exports = router;