const express = require("express");
const router = express.Router();
const User = require("../models/user");
const bodyParser = require("body-parser");
console.log("entered users ");

router.post("/username", async (req, res) => {
 try{
        console.log("entered users post1e");
        let user = await User.findOne({ username: req.body.username });
         console.log("entered users post2e");
         console.log("username"+req.body.username);
         if (user){
         console.log("user "+user);
         return res.send(user);
         }else{
            return res.status(400).send("User do not exists");
         }
        }catch(error){
            console.log(error);
        }
});


router.post("/", async (req, res) => {
    console.log("entered users post");
       try{
        console.log("entered users post1");
        let user = await User.findOne({ username: req.body.username });
         console.log("entered users post2");

         if (user){
         return res.status(400).send("User already exists");
         }
        }catch(error){
            console.log(error);
        }
       console.log("entered users post4");
        const newuser = new User({
            username: req.body.username,
            password: req.body.password,
            isTeacher: req.body.isTeacher,
        });
        console.log("e"+req.body.username);
        console.log("e"+req.body.password);
        console.log("e"+req.body.isTeacher);

        console.log("entered users post5");
         newuser
        .save()
        .then(newuser => {
        console.log("entered users post6");
          res.status(200).send(newuser);
        })
        .catch((err) => {
          res.status(500).send(err.message);
        });
       
   

    });

module.exports = router;
